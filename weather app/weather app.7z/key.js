//Assign the copied API key to the 'key' variable
key = "260e9116ef636bd89ecea8f5128f487c";